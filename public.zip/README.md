# Challenge U Web Platform

A modern web platform with authentication, collaboration, and mentorship features.

## Project Structure

```
Web/
├── public/
│   ├── css/
│   │   ├── auth/
│   │   │   └── auth.css         # Authentication styles
│   │   ├── components/
│   │   │   └── ui.css           # Shared UI components
│   │   └── pages/
│   │       ├── collaborate.css   # Collaboration page styles
│   │       ├── find-mentor.css   # Mentor finding page styles
│   │       ├── join-team.css     # Team joining page styles
│   │       ├── resources.css     # Resources page styles
│   │       └── styles.css        # Global styles
│   ├── js/
│   │   ├── auth/
│   │   │   └── auth.js          # Authentication scripts
│   │   ├── components/
│   │   │   └── ui.js            # Shared UI components
│   │   └── pages/
│   │       └── script.js         # Page-specific scripts
│   ├── images/                   # Image assets
│   ├── fonts/                    # Custom fonts
│   └── videos/                   # Video content
├── pages/
│   ├── collaborate.html          # Collaboration page
│   ├── find-mentor.html          # Mentor finding page
│   ├── join-team.html           # Team joining page
│   └── resources.html           # Resources page
├── index.html                   # Home page
├── sign-in.html                # Sign in page
├── sign-up.html                # Multi-step sign up page
└── README.md                   # Project documentation
```

## Features

### Authentication
- Multi-step registration process
- Social sign-in options (Google, Apple)
- Password visibility toggle
- Real-time form validation
- Team member invitation system

### UI Components
- Toast notifications
- Loading spinners
- Tooltips
- Modal dialogs
- Responsive navigation
- Form elements
- Cards
- Badges

### Pages
- Home
- Authentication (Sign In/Sign Up)
- Find Mentor
- Join Team
- Collaborate
- Resources

## Dependencies

- Font Awesome 6.4.0 (CDN)
- Inter Font (Google Fonts)
- Custom SVG icons

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Getting Started

1. Clone the repository
2. No build process required - pure HTML, CSS, and JavaScript
3. Open `index.html` in a modern web browser

## Development

The project uses a modular structure:
- Components are shared across pages
- Styles are organized by feature and component
- JavaScript is modular and feature-based
- Assets are properly organized in the public directory

### CSS Organization
- `components/ui.css`: Shared UI components
- `auth/auth.css`: Authentication-specific styles
- `pages/*.css`: Page-specific styles

### JavaScript Organization
- `components/ui.js`: Shared UI functionality
- `auth/auth.js`: Authentication-specific scripts
- `pages/script.js`: Page-specific scripts

## Future Improvements

1. Backend integration
2. Enhanced form validation
3. Comprehensive error handling
4. Accessibility improvements
5. Cross-browser testing
6. Build process implementation
7. CSS preprocessing
8. JavaScript bundling
