// Form initialization
document.addEventListener('DOMContentLoaded', () => {
    initializePasswordToggles();
    initializePasswordStrength();
    initializeForms();
    initializeSocialLogin();
    storeOriginalButtonText();
});

// Password visibility toggle
function initializePasswordToggles() {
    document.querySelectorAll('.password-toggle').forEach(button => {
        button.addEventListener('click', function() {
            const input = this.parentElement.querySelector('input');
            const icon = this.querySelector('i');
            const isVisible = input.type === 'text';
            
            input.type = isVisible ? 'password' : 'text';
            icon.classList.toggle('fa-eye', isVisible);
            icon.classList.toggle('fa-eye-slash', !isVisible);
            this.setAttribute('aria-label', `${isVisible ? 'Show' : 'Hide'} password`);
        });
    });
}

// Password strength checker
function initializePasswordStrength() {
    const passwordInput = document.getElementById('password');
    const strengthBar = document.querySelector('.strength-bar');
    const strengthText = document.querySelector('.strength-text span');

    if (!(passwordInput && strengthBar && strengthText)) return;

    const strengthColors = {
        weak: '#ef4444',
        medium: '#f59e0b',
        strong: '#10b981'
    };

    const strengthCriteria = [
        { regex: /.{8,}/, points: 1 },    // Minimum length of 8
        { regex: /.{12,}/, points: 1 },   // Preferred length of 12
        { regex: /[A-Z]/, points: 1 },    // Uppercase letters
        { regex: /[a-z]/, points: 1 },    // Lowercase letters
        { regex: /[0-9]/, points: 1 },    // Numbers
        { regex: /[^A-Za-z0-9]/, points: 1 } // Special characters
    ];

    passwordInput.addEventListener('input', function() {
        const password = this.value;
        let strength = strengthCriteria.reduce((score, criterion) => 
            score + (criterion.regex.test(password) ? criterion.points : 0), 0);

        let strengthLevel = {
            width: '0%',
            text: 'Weak',
            color: strengthColors.weak
        };

        if (strength >= 5) {
            strengthLevel = {
                width: '100%',
                text: 'Strong',
                color: strengthColors.strong
            };
        } else if (strength >= 3) {
            strengthLevel = {
                width: '66%',
                text: 'Medium',
                color: strengthColors.medium
            };
        } else if (strength >= 1) {
            strengthLevel = {
                width: '33%',
                text: 'Weak',
                color: strengthColors.weak
            };
        }

        strengthBar.style.setProperty('--strength-width', strengthLevel.width);
        strengthBar.style.setProperty('--strength-color', strengthLevel.color);
        strengthBar.setAttribute('aria-valuenow', parseInt(strengthLevel.width));
        strengthText.textContent = strengthLevel.text;
        strengthText.style.color = strengthLevel.color;
    });
}

// Form validation
function initializeForms() {
    document.querySelectorAll('.auth-form').forEach(form => {
        // Real-time validation
        form.querySelectorAll('input').forEach(input => {
            input.addEventListener('blur', () => validateField(input));
            input.addEventListener('input', () => {
                if (input.classList.contains('error')) {
                    validateField(input);
                }
            });
        });

        // Form submission
        form.addEventListener('submit', handleFormSubmit);
    });
}

function validateField(input) {
    const validations = {
        required: (value) => value.trim() !== '' || 'This field is required',
        email: (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) || 'Please enter a valid email address',
        minLength: (value, length) => value.length >= length || `Must be at least ${length} characters`,
        passwordMatch: (value, confirmValue) => value === confirmValue || 'Passwords do not match'
    };

    clearError(input);
    let isValid = true;
    let errorMessage = '';

    // Required validation
    if (input.hasAttribute('required')) {
        const requiredResult = validations.required(input.value);
        if (requiredResult !== true) {
            isValid = false;
            errorMessage = requiredResult;
        }
    }

    // Email validation
    if (isValid && input.type === 'email') {
        const emailResult = validations.email(input.value);
        if (emailResult !== true) {
            isValid = false;
            errorMessage = emailResult;
        }
    }

    // Minimum length validation
    if (isValid && input.hasAttribute('minlength')) {
        const minLength = parseInt(input.getAttribute('minlength'));
        const minLengthResult = validations.minLength(input.value, minLength);
        if (minLengthResult !== true) {
            isValid = false;
            errorMessage = minLengthResult;
        }
    }

    // Password match validation
    if (isValid && input.id === 'confirmPassword') {
        const password = document.getElementById('password');
        if (password) {
            const matchResult = validations.passwordMatch(input.value, password.value);
            if (matchResult !== true) {
                isValid = false;
                errorMessage = matchResult;
            }
        }
    }

    if (!isValid) {
        showError(input, errorMessage);
    }

    return isValid;
}

function handleFormSubmit(e) {
    e.preventDefault();
    const form = e.target;
    
    // Validate all fields
    const fields = Array.from(form.querySelectorAll('input[required]'));
    const isValid = fields.every(field => validateField(field));

    if (isValid) {
        const submitBtn = form.querySelector('.auth-submit');
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        
        // Show loading state
        setSubmitButtonState(submitBtn, true);

        // Simulate API call
        simulateApiCall(data)
            .then(() => {
                // Success - redirect to dashboard
                window.location.href = 'index.html';
            })
            .catch(error => {
                // Show error message
                showFormError(form, error.message);
                setSubmitButtonState(submitBtn, false);
            });
    }
}

// Helper functions
function showError(input, message) {
    const group = input.closest('.input-group');
    group.classList.add('error');
    input.setAttribute('aria-invalid', 'true');
    
    const error = document.createElement('span');
    error.className = 'error-message';
    error.setAttribute('role', 'alert');
    error.textContent = message;
    
    group.parentElement.appendChild(error);
}

function clearError(input) {
    const group = input.closest('.input-group');
    group.classList.remove('error');
    input.setAttribute('aria-invalid', 'false');
    
    const error = group.parentElement.querySelector('.error-message');
    if (error) error.remove();
}

function showFormError(form, message) {
    const existingError = form.querySelector('.form-error');
    if (existingError) existingError.remove();

    const error = document.createElement('div');
    error.className = 'form-error';
    error.setAttribute('role', 'alert');
    error.textContent = message;
    
    form.insertBefore(error, form.firstChild);
}

function setSubmitButtonState(button, loading) {
    button.disabled = loading;
    const span = button.querySelector('span');
    if (loading) {
        span.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
        button.setAttribute('aria-busy', 'true');
    } else {
        span.textContent = button.dataset.originalText || 'Submit';
        button.removeAttribute('aria-busy');
    }
}

function simulateApiCall(data) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (Math.random() > 0.1) { // 90% success rate
                resolve(data);
            } else {
                reject(new Error('Authentication failed. Please try again.'));
            }
        }, 1500);
    });
}

// Social login initialization
function initializeSocialLogin() {
    document.querySelectorAll('.social-btn').forEach(button => {
        button.addEventListener('click', function() {
            const provider = this.classList.contains('google') ? 'Google' : 'GitHub';
            const originalContent = this.innerHTML;
            
            // Show loading state
            this.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Connecting...`;
            this.disabled = true;

            // Simulate OAuth flow
            setTimeout(() => {
                this.innerHTML = originalContent;
                this.disabled = false;
                console.log(`Initiating ${provider} login...`);
                // Here you would implement the actual OAuth flow
            }, 1500);
        });
    });
}

// Store original button text
function storeOriginalButtonText() {
    document.querySelectorAll('.auth-submit').forEach(button => {
        const span = button.querySelector('span');
        if (span) {
            button.dataset.originalText = span.textContent;
        }
    });
}
